"use strict";

/*
 * FaceFX - Crisp 184x184 native pixel expression layer for the white dragon.
 * Uses per-frame baked head landmarks [fx, fy, nx, ny] so eyebrows, blush,
 * live eye-tracking catchlights, micro-blinks and high-charm state mouths
 * align cleanly in both full and close views without pixel boiling.
 */
window.FaceFX = (() => {
  const SKIN = "#fff0e6";
  const SKIN_SHADE = "#eeded3";
  const INK = "#493b54";
  const INK_SOFT = "#6e5d7d";
  const BROW = "#685878";
  const BROW_SOFT = "#8d7ea0";
  const BLUSH_SOFT = "#f8c6d2";
  const BLUSH_CORE = "#f19eb3";
  const BLUSH_STROKE = "#e87e99";
  const MOUTH_LINE = "#a66c7a";
  const MOUTH_FILL = "#e88a9e";
  const TONGUE = "#f7b3c0";

  function px(ctx, x, y, w, h, color) {
    ctx.fillStyle = color;
    ctx.fillRect(Math.round(x), Math.round(y), w, h);
  }

  function star(ctx, x, y, color, r = 1) {
    const cx = Math.round(x), cy = Math.round(y);
    px(ctx, cx - r, cy, r * 2 + 1, 1, color);
    px(ctx, cx, cy - r, 1, r * 2 + 1, color);
  }

  /*
   * Bangs-preserving eye socket clearer!
   * Flood-fills white/silver-lavender hair locks connected to the top & sides
   * of the eye bounding box (excluding violet lower-iris B-R>=16 & dark iris R<155),
   * so front bangs and side locks stay 100% crisp in front of closed/half-lidded eyes.
   * Falls back safely to a compact lower-socket patch if canvas is tainted (file://).
   */
  function clearEyeSocket(ctx, cx, cy, rx, ry, maxDy = ry) {
    const icx = Math.round(cx), icy = Math.round(cy);
    const x0 = Math.max(0, Math.floor(cx - rx) - 1);
    const y0 = Math.max(0, Math.floor(cy - ry) - 1);
    const x1 = Math.min(183, Math.ceil(cx + rx) + 1);
    const y1 = Math.min(183, Math.ceil(cy + maxDy) + 1);
    const w = x1 - x0 + 1;
    const h = y1 - y0 + 1;
    const hair = new Uint8Array(w * h);

    let data = null;
    try {
      data = ctx.getImageData(x0, y0, w, h).data;
    } catch {
      // Tainted file:// canvas fallback: keep top bangs safe by only covering below bangs tips.
      const fw = Math.max(2, Math.round(rx * 1.45));
      const fTop = Math.round(cy - ry * 0.25);
      const fBot = Math.round(cy + Math.min(maxDy, ry * 0.85));
      px(ctx, icx - Math.floor(fw / 2), fTop, fw, Math.max(1, fBot - fTop + 1), SKIN);
      return { x0, y0, w, h, hair };
    }

    const isHairFill = (idx) => {
      const r = data[idx], g = data[idx + 1], b = data[idx + 2], a = data[idx + 3];
      if (a < 200) return false;
      // Exclude pure #ffffff eye catchlights (hair white is #f9f5fa) and warm skin (r > b + 6).
      if (r === 255 && g === 255 && b === 255) return false;
      // Exact silver-white / soft-lavender hair range (#f9f5fa, #eee7f3, #dfd4e7, #cdc0d5):
      // lower-iris lavender (#e1d1f2, #cbb8e0, #ae9aca) has b - r >= 16!
      return r >= 188 && g >= 176 && b >= 194 && b >= r - 2 && b - r <= 14;
    };
    const isHairOutline = (idx) => {
      const r = data[idx], g = data[idx + 1], b = data[idx + 2], a = data[idx + 3];
      if (a < 200) return false;
      // Soft hair crease / outline (#b6a8c3, #a095ac), never dark eyelash (r < 155).
      return r >= 155 && g >= 144 && b >= 166 && b >= r + 4 && b - r <= 15;
    };

    const queue = [];
    const midY = icy - y0;
    for (let lx = 0; lx < w; lx++) {
      for (let ly = 0; ly < h; ly++) {
        const onTop = ly === 0;
        const onUpperSide = (lx === 0 || lx === w - 1) && ly <= midY + 2;
        if (!onTop && !onUpperSide) continue;
        const k = ly * w + lx;
        if (!hair[k] && isHairFill(k * 4)) {
          hair[k] = 1;
          queue.push(k);
        }
      }
    }
    for (let head = 0; head < queue.length; head++) {
      const k = queue[head];
      const lx = k % w, ly = (k - lx) / w;
      for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const nx = lx + dx, ny = ly + dy;
        if (nx < 0 || nx >= w || ny < 0 || ny >= h) continue;
        const nk = ny * w + nx;
        if (!hair[nk] && isHairFill(nk * 4)) {
          hair[nk] = 1;
          queue.push(nk);
        }
      }
    }
    // Preserve 1px soft lavender hair outline hugging the bangs tips (never dark eyelashes).
    const outlineMark = new Uint8Array(w * h);
    for (let ly = 0; ly < h; ly++) {
      for (let lx = 0; lx < w; lx++) {
        const k = ly * w + lx;
        if (hair[k] || !isHairOutline(k * 4)) continue;
        let touchesHair = false;
        for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
          const nx = lx + dx, ny = ly + dy;
          if (nx >= 0 && nx < w && ny >= 0 && ny < h && hair[ny * w + nx]) {
            touchesHair = true;
            break;
          }
        }
        if (touchesHair) outlineMark[k] = 1;
      }
    }
    for (let k = 0; k < w * h; k++) {
      if (outlineMark[k]) hair[k] = 1;
    }

    // Replace ONLY non-hair, non-skin eye-socket pixels inside the ellipse!
    for (let ly = 0; ly < h; ly++) {
      const py = y0 + ly;
      const dy = py - cy;
      if (dy > maxDy) continue;
      for (let lx = 0; lx < w; lx++) {
        const k = ly * w + lx;
        if (hair[k]) continue;
        const pxX = x0 + lx;
        const dx = pxX - cx;
        if ((dx * dx) / (rx * rx) + (dy * dy) / (ry * ry) > 1.04) continue;
        const idx = k * 4;
        const r = data[idx], g = data[idx + 1], b = data[idx + 2], a = data[idx + 3];
        if (a < 200) continue;
        // Skip warm skin & blush tones already on the cheek/nose bridge.
        if (r >= 218 && r - b >= 14) continue;
        // Soft natural skin shadow 1px directly underneath bangs tips!
        const underHair = ly > 0 && hair[(ly - 1) * w + lx];
        px(ctx, pxX, py, 1, 1, underHair ? SKIN_SHADE : SKIN);
      }
    }
    return { x0, y0, w, h, hair };
  }

  function pxBehindHair(ctx, mask, x, y, color) {
    const ix = Math.round(x), iy = Math.round(y);
    if (mask) {
      const lx = ix - mask.x0, ly = iy - mask.y0;
      if (lx >= 0 && lx < mask.w && ly >= 0 && ly < mask.h && mask.hair[ly * mask.w + lx]) {
        return;
      }
    }
    px(ctx, ix, iy, 1, 1, color);
  }

  function eyesClosedMask(action, frame, sulkPhase) {
    // Returns [leftClosed, rightClosed] where baked sprite already closes eyes.
    if (action === "doze" && frame >= 10) return [true, true];
    if (action === "peekLeft") return [false, true];
    if (action === "peekRight") return [true, false];
    if ((action === "wakeLeft" || action === "wakeRight") && frame < 10) return [true, true];
    if ((action === "pat" || action === "patLeft") && frame >= 4 && frame <= 23) return [true, true];
    if (action === "tickle" && frame >= 3 && frame <= 24) return [true, true];
    if (action === "idleHum" && frame >= 2 && frame <= 11) return [true, true];
    if (action === "idleYawn" && frame >= 6 && frame <= 19) return [true, true];
    if (action === "sneeze" && frame >= 11 && frame <= 20) return [true, true];
    if (action === "cheekLeft" && frame >= 2 && frame <= 16) return [true, false];
    if (action === "cheekRight" && frame >= 2 && frame <= 16) return [false, true];
    if (action === "heartHug" && frame >= 14 && frame <= 27) return [true, false];
    if (action === "starCatchLeft" && frame >= 14 && frame <= 25) return [false, true];
    if (action === "starCatchRight" && frame >= 14 && frame <= 25) return [true, false];
    if (action === "lensFind" && frame >= 6 && frame <= 19) return [false, true];
    if (action === "brush" && frame >= 18) return [true, true];
    if ((action === "browInviteLeft" || action === "browInviteRight") &&
        ((frame >= 24 && frame <= 36) || (frame >= 55 && frame <= 60) || frame >= 82)) {
      return [true, true];
    }
    void sulkPhase;
    return [false, false];
  }

  function drawBlush(ctx, lx, ly, rx, ry, close, level, sulking) {
    // Level: 0=always-on gentle rose, 1=warm happy, 2=rosy anime blush (///).
    const w = close ? 5 : 3;
    const h = close ? 2 : 1;
    const leftX = Math.round(lx) - Math.floor(w / 2);
    const rightX = Math.round(rx) - Math.floor(w / 2);
    const leftY = Math.round(ly);
    const rightY = Math.round(ry);
    const tone = level >= 2 || sulking ? BLUSH_CORE : BLUSH_SOFT;
    px(ctx, leftX, leftY, w, h, tone);
    px(ctx, rightX, rightY, w, h, tone);
    if (level >= 1 || sulking) {
      if (close) {
        px(ctx, leftX + 1, leftY, 3, 1, BLUSH_CORE);
        px(ctx, rightX + 1, rightY, 3, 1, BLUSH_CORE);
      }
    }
    if (level >= 2 || sulking) {
      if (close) {
        px(ctx, leftX + 1, leftY, 1, 2, BLUSH_STROKE);
        px(ctx, leftX + 3, leftY, 1, 2, BLUSH_STROKE);
        px(ctx, rightX + 1, rightY, 1, 2, BLUSH_STROKE);
        px(ctx, rightX + 3, rightY, 1, 2, BLUSH_STROKE);
      } else {
        px(ctx, leftX + 1, leftY, 1, 1, BLUSH_STROKE);
        px(ctx, rightX + 1, rightY, 1, 1, BLUSH_STROKE);
      }
    }
  }

  function drawBrows(ctx, lx, ly, rx, ry, close, style) {
    // Crisp over-the-bangs anime pixel eyebrows.
    const c = style === "soft" ? BROW_SOFT : BROW;
    const Lx = Math.round(lx), Ly = Math.round(ly);
    const Rx = Math.round(rx), Ry = Math.round(ry);
    const span = close ? 4 : 3;
    if (style === "worried") {
      // Slanted inner-up worried brows (/  \) like CrossPet oops.
      if (close) {
        px(ctx, Lx - 2, Ly + 1, 2, 1, c);
        px(ctx, Lx, Ly, 2, 1, c);
        px(ctx, Lx + 2, Ly - 1, 1, 1, c);
        px(ctx, Rx - 2, Ry - 1, 1, 1, c);
        px(ctx, Rx - 1, Ry, 2, 1, c);
        px(ctx, Rx + 1, Ry + 1, 2, 1, c);
      } else {
        px(ctx, Lx - 1, Ly + 1, 1, 1, c);
        px(ctx, Lx, Ly, 2, 1, c);
        px(ctx, Rx - 1, Ry, 2, 1, c);
        px(ctx, Rx + 1, Ry + 1, 1, 1, c);
      }
    } else if (style === "pout") {
      // Cute sharp tsundere pout brows (\  /).
      if (close) {
        px(ctx, Lx - 2, Ly - 1, 2, 1, INK);
        px(ctx, Lx, Ly, 2, 1, INK);
        px(ctx, Lx + 2, Ly + 1, 1, 1, INK);
        px(ctx, Rx - 2, Ry + 1, 1, 1, INK);
        px(ctx, Rx - 1, Ry, 2, 1, INK);
        px(ctx, Rx + 1, Ry - 1, 2, 1, INK);
      } else {
        px(ctx, Lx - 1, Ly - 1, 1, 1, INK);
        px(ctx, Lx, Ly, 2, 1, INK);
        px(ctx, Rx - 1, Ry, 2, 1, INK);
        px(ctx, Rx + 1, Ry - 1, 1, 1, INK);
      }
    } else if (style === "tired") {
      // Low drooping tired brows.
      px(ctx, Lx - 2, Ly + 1, span, 1, c);
      px(ctx, Rx - 1, Ry + 1, span, 1, c);
    } else if (style === "curious") {
      // Cute asymmetric brow tilt (right brow raised 1px).
      px(ctx, Lx - 1, Ly, span, 1, c);
      px(ctx, Rx - 1, Ry - 1, span, 1, c);
    } else if (style === "happy" || style === "expectant") {
      const lift = style === "expectant" ? -1 : 0;
      if (close) {
        px(ctx, Lx - 2, Ly + lift + 1, 1, 1, c);
        px(ctx, Lx - 1, Ly + lift, 3, 1, c);
        px(ctx, Rx - 1, Ry + lift, 3, 1, c);
        px(ctx, Rx + 2, Ry + lift + 1, 1, 1, c);
      } else {
        px(ctx, Lx - 1, Ly + lift, 3, 1, c);
        px(ctx, Rx - 1, Ry + lift, 3, 1, c);
      }
    } else {
      // Soft delicate default brows.
      px(ctx, Lx - 1, Ly, close ? 3 : 2, 1, c);
      px(ctx, Rx - 1, Ry, close ? 3 : 2, 1, c);
    }
  }

  function drawOpenEyeAccents(ctx, cx, cy, close, gx, gy, mode, tick, motion) {
    const x = Math.round(cx), y = Math.round(cy);
    if (mode === "star") {
      // Sparkling starlight eyes (✦) for succeeded / reunion!
      const ox = Math.round(gx * (close ? 1 : 0.6));
      const pulse = motion && Math.floor(tick / 220) % 2 === 0;
      if (close) {
        px(ctx, x - 3 + ox, y - 2, 2, 2, "#fffaff");
        star(ctx, x + 1 + ox, y + 1, pulse ? "#fff6c4" : "#ffe699", 2);
        px(ctx, x + 1 + ox, y + 1, 1, 1, "#ffffff");
      } else {
        px(ctx, x - 2 + ox, y - 1, 2, 1, "#fffaff");
        star(ctx, x + ox, y + 1, pulse ? "#fff6c4" : "#ffe699", 1);
        px(ctx, x + ox, y + 1, 1, 1, "#ffffff");
      }
      return;
    }
    if (mode === "tired") {
      // Heavy droopy half-closed eyelid cleanly tucked BEHIND front bangs!
      const rx = close ? 8.6 : 5.6;
      const ry = close ? 7.0 : 4.8;
      const maxDy = close ? -0.2 : 0.0;
      const mask = clearEyeSocket(ctx, cx, cy, rx, ry, maxDy);
      const lidY = y;
      const halfSpan = close ? 5 : 3;
      for (let dx = -halfSpan; dx <= halfSpan; dx++) {
        pxBehindHair(ctx, mask, x + dx, lidY, Math.abs(dx) === halfSpan ? INK_SOFT : INK);
      }
      // Subtle dim highlight in lower visible half of iris
      pxBehindHair(ctx, mask, x - (close ? 2 : 1), lidY + (close ? 2 : 1), "#e4daf6");
      return;
    }
    if (mode === "soft") {
      // Gentle serene shimmer for 'ended' — keeps 100% of the artist's relaxed eyes intact!
      const dx = Math.max(-1, Math.min(1, Math.round(gx)));
      const dy = Math.max(0, Math.min(1, Math.round(gy)));
      if (close) {
        px(ctx, x - 2 + dx, y - 1 + dy, 2, 1, "#fff8ff");
        px(ctx, x + 1 + dx, y + 2 + dy, 2, 1, "#f2e7ff");
      } else {
        px(ctx, x - 1 + dx, y - 1 + dy, 1, 1, "#fff8ff");
        px(ctx, x + 1 + dx, y + 1 + dy, 1, 1, "#f2e7ff");
      }
      return;
    }
    // Live sparkling catchlight & subtle pupil focus tracking cursor/gaze!
    const dx = Math.max(-2, Math.min(2, Math.round(gx * (close ? 2 : 1))));
    const dy = Math.max(-1, Math.min(1, Math.round(gy * (close ? 1.2 : 0.8))));
    if (close) {
      // Deep crisp pupil accent
      px(ctx, x + dx, y - 1 + dy, 2, 2, "#463864");
      // Bright primary top-left starlight catchlight
      px(ctx, x - 2 + dx, y - 2 + dy, 2, 2, "#fffaff");
      // Secondary lower rim sparkle
      px(ctx, x + 2 + dx, y + 2 + dy, 1, 1, "#f2e7ff");
      if (mode === "bright") {
        px(ctx, x - 1 + dx, y + 2 + dy, 2, 1, "#ffeeb8");
      }
    } else {
      px(ctx, x + dx, y + dy, 1, 1, "#463864");
      px(ctx, x - 1 + dx, y - 1 + dy, 2, 1, "#fffaff");
      px(ctx, x + 1 + dx, y + 1 + dy, 1, 1, "#efe3ff");
    }
  }

  function drawMouth(ctx, mx, my, close, style) {
    const x = Math.round(mx), y = Math.round(my);
    if (style === "none") return;
    // Clear the tiny baked dot cleanly with exact face skin tone.
    px(ctx, x - (close ? 3 : 2), y - 1, close ? 7 : 5, close ? 4 : 3, SKIN);
    if (style === "cat") {
      // Adorable clean w / ω cat smile!
      if (close) {
        px(ctx, x - 3, y, 1, 1, MOUTH_LINE);
        px(ctx, x - 2, y + 1, 2, 1, MOUTH_LINE);
        px(ctx, x, y, 1, 1, MOUTH_LINE);
        px(ctx, x + 1, y + 1, 2, 1, MOUTH_LINE);
        px(ctx, x + 3, y, 1, 1, MOUTH_LINE);
      } else {
        px(ctx, x - 2, y, 1, 1, MOUTH_LINE);
        px(ctx, x - 1, y + 1, 1, 1, MOUTH_LINE);
        px(ctx, x, y, 1, 1, MOUTH_LINE);
        px(ctx, x + 1, y + 1, 1, 1, MOUTH_LINE);
        px(ctx, x + 2, y, 1, 1, MOUTH_LINE);
      }
    } else if (style === "smile") {
      if (close) {
        px(ctx, x - 2, y, 1, 1, MOUTH_LINE);
        px(ctx, x - 1, y + 1, 3, 1, MOUTH_LINE);
        px(ctx, x + 2, y, 1, 1, MOUTH_LINE);
      } else {
        px(ctx, x - 1, y, 1, 1, MOUTH_LINE);
        px(ctx, x, y + 1, 1, 1, MOUTH_LINE);
        px(ctx, x + 1, y, 1, 1, MOUTH_LINE);
      }
    } else if (style === "wavy") {
      // Flustered wavy mouth (﹏) for error!
      if (close) {
        px(ctx, x - 3, y + 1, 1, 1, MOUTH_LINE);
        px(ctx, x - 2, y, 1, 1, MOUTH_LINE);
        px(ctx, x - 1, y + 1, 2, 1, MOUTH_LINE);
        px(ctx, x + 1, y, 1, 1, MOUTH_LINE);
        px(ctx, x + 2, y + 1, 1, 1, MOUTH_LINE);
      } else {
        px(ctx, x - 2, y + 1, 1, 1, MOUTH_LINE);
        px(ctx, x - 1, y, 1, 1, MOUTH_LINE);
        px(ctx, x, y + 1, 1, 1, MOUTH_LINE);
        px(ctx, x + 1, y, 1, 1, MOUTH_LINE);
      }
    } else if (style === "pout") {
      // Cute tsundere pout (へ)
      if (close) {
        px(ctx, x - 2, y + 1, 2, 1, MOUTH_LINE);
        px(ctx, x, y, 2, 1, MOUTH_LINE);
        px(ctx, x + 2, y + 1, 1, 1, MOUTH_LINE);
      } else {
        px(ctx, x - 1, y + 1, 1, 1, MOUTH_LINE);
        px(ctx, x, y, 2, 1, MOUTH_LINE);
      }
    } else if (style === "smallO" || style === "yawnO") {
      const big = style === "yawnO" && close;
      if (big) {
        px(ctx, x - 1, y - 2, 3, 1, MOUTH_LINE);
        px(ctx, x - 2, y - 1, 1, 3, MOUTH_LINE);
        px(ctx, x + 2, y - 1, 1, 3, MOUTH_LINE);
        px(ctx, x - 1, y - 1, 3, 3, MOUTH_FILL);
        px(ctx, x, y + 1, 1, 1, TONGUE);
        px(ctx, x - 1, y + 2, 3, 1, MOUTH_LINE);
      } else if (close) {
        px(ctx, x - 1, y - 1, 3, 1, MOUTH_LINE);
        px(ctx, x - 1, y, 1, 1, MOUTH_LINE);
        px(ctx, x, y, 1, 1, TONGUE);
        px(ctx, x + 1, y, 1, 1, MOUTH_LINE);
        px(ctx, x - 1, y + 1, 3, 1, MOUTH_LINE);
      } else {
        // Soft delicate tiny 'o' in full view (avoids chunky square dot!)
        px(ctx, x, y - 1, 1, 1, MOUTH_LINE);
        px(ctx, x - 1, y, 1, 1, MOUTH_LINE);
        px(ctx, x, y, 1, 1, TONGUE);
        px(ctx, x + 1, y, 1, 1, MOUTH_LINE);
        px(ctx, x, y + 1, 1, 1, MOUTH_LINE);
      }
    }
  }

  function drawHeartJewel(ctx, cx, cy, close) {
    const x = Math.round(cx), y = Math.round(cy);
    const pattern = close
      ? [
          ".oo...oo.",
          "orwo.orro",
          "orwrorrro",
          "orrrrrrro",
          ".orrrrro.",
          "..orrro..",
          "...oro...",
          "....o....",
        ]
      : [
          ".o...o.",
          "orw.rro",
          "orrrrro",
          ".orrro.",
          "..oro..",
          "...o...",
        ];
    const map = { o: "#6f425b", r: "#ef6d8c", w: "#fff3ea" };
    const ox = Math.floor(pattern[0].length / 2);
    const oy = Math.floor(pattern.length / 2);
    for (let j = 0; j < pattern.length; j++) {
      for (let i = 0; i < pattern[j].length; i++) {
        const col = map[pattern[j][i]];
        if (col) px(ctx, x - ox + i, y - oy + j, 1, 1, col);
      }
    }
  }

  function draw(ctx, display, opts) {
    const {
      clip, frame, view, action, agentState, tick, motion,
      gazeX = 0, gazeY = 0, sulkPhase = null, reunion = false, bondLevel = 0,
    } = opts;
    if (!clip?.anchors?.[frame]) return;
    const a = clip.anchors[frame];
    const [fx, fy, nx, ny] = a;
    const vx = nx - fx, vy = ny - fy;
    const rx = vy, ry = -vx;
    const close = view === "close";

    const pt = (u, w) => display.facePoint(view, clip, frame, nx + u * rx + w * vx, ny + u * ry + w * vy);
    const lEye = pt(-0.395, -0.285);
    const rEye = pt(0.375, -0.285);
    const lBrow = pt(-0.39, -0.49);
    const rBrow = pt(0.37, -0.49);
    const lCheek = pt(-0.39, -0.02);
    const rCheek = pt(0.37, -0.02);
    const mouth = pt(-0.015, 0.085);

    const sulking = Boolean(sulkPhase) && agentState === "idle" && action === "idle";
    const isReunion = Boolean(reunion) && agentState === "idle" && action === "idle";
    const isBaseState = action === agentState || (action === "readingMoon" && agentState === "reading");
    const [leftClosed, rightClosed] = eyesClosedMask(action, frame, sulkPhase);

    // 1. Determine warm peach-rose blush intensity (drawn right after eye masks so cheeks stay vivid!)
    let blushLevel = bondLevel >= 3 ? 1 : 0;
    if (
      ["pat", "patLeft", "brush", "tickle", "heartHug", "cheekLeft", "cheekRight", "browInviteLeft", "browInviteRight"].includes(action) ||
      (isBaseState && agentState === "succeeded") ||
      isReunion
    ) {
      blushLevel = 2;
    } else if (isBaseState && (agentState === "ended" || agentState === "waiting")) {
      blushLevel = 1;
    }

    // 2. Special eye & mouth overrides for high-readability acting!
    let eyeMode = "normal";
    let browStyle = "soft";
    let mouthStyle = "none";
    let effGazeX = gazeX, effGazeY = gazeY;

    if (sulking) {
      browStyle = "pout";
      mouthStyle = "pout";
      effGazeX = sulkPhase === "peek" ? 0.15 : -0.9;
      effGazeY = sulkPhase === "peek" ? -0.2 : 0.25;
    } else if (isReunion) {
      eyeMode = "star";
      browStyle = "happy";
      mouthStyle = "cat";
    } else if (action === "sneeze" && frame >= 14 && frame <= 19) {
      // Keep the artist's clean baked closed eyes in sneeze.png intact; add worried brows & cute 'o'.
      browStyle = "worried";
      mouthStyle = "smallO";
    } else if (action === "idleYawn" && frame >= 8 && frame <= 18) {
      browStyle = "tired";
      mouthStyle = "yawnO";
      // Tiny sleepy tear glint at outer eye corner
      px(ctx, rEye.sx + (close ? 5 : 3), rEye.sy + 2, 1, 2, "#c5e7d4");
    } else if (isBaseState && agentState === "succeeded") {
      eyeMode = "star";
      browStyle = "happy";
      mouthStyle = "cat";
    } else if (isBaseState && agentState === "error") {
      browStyle = "worried";
      mouthStyle = "wavy";
      const jitter = motion && Math.floor(tick / 140) % 2 === 0 ? 0.35 : -0.35;
      effGazeX = jitter;
      effGazeY = 0.2;
      // Forehead blue anime gloom lines (|||)
      const gloom = pt(-0.02, -0.58);
      for (const ox of [-3, 0, 3]) {
        px(ctx, gloom.sx + ox, gloom.sy, 1, close ? 4 : 3, "#789bb3");
      }
      // Glistening animated sweatdrop beside right eye
      const drop = pt(0.58, -0.34);
      const bob = motion ? Math.floor((tick % 900) / 300) : 0;
      px(ctx, drop.sx, drop.sy + bob, 2, 3, "#a8dfd8");
      px(ctx, drop.sx + 1, drop.sy + bob, 1, 1, "#ffffff");
      px(ctx, drop.sx, drop.sy + 3 + bob, 2, 1, "#55798f");
    } else if (isBaseState && agentState === "limited") {
      eyeMode = "tired";
      browStyle = "tired";
      mouthStyle = "pout";
      // Slowly rising white pixel sigh cloud (~)
      const sigh = pt(0.24, 0.08);
      const phase = motion ? Math.floor((tick % 2200) / 360) : 2;
      if (phase >= 1 && phase <= 4) {
        const sx = sigh.sx + phase;
        const sy = sigh.sy - Math.floor(phase / 2);
        px(ctx, sx, sy, 3, 1, "#e8e3f2");
        px(ctx, sx + 1, sy - 1, 2, 1, "#ffffff");
        px(ctx, sx, sy + 1, 2, 1, "#9b8fa8");
      }
    } else if (isBaseState && agentState === "ended") {
      // Preserve 100% of ended.png's serene artist-drawn relaxed eyes & F8 sigh!
      eyeMode = "soft";
      browStyle = "soft";
      mouthStyle = frame >= 6 && frame <= 13 ? "none" : "smile";
      effGazeX = gazeX * 0.45;
      effGazeY = 0.35;
    } else if (isBaseState && agentState === "cancelled") {
      browStyle = "curious";
      mouthStyle = "smallO";
      effGazeX = -0.8;
      effGazeY = -0.2;
    } else if (isBaseState && agentState === "waiting") {
      eyeMode = "bright";
      browStyle = "expectant";
      mouthStyle = "smile";
    } else if (isBaseState && agentState === "working") {
      browStyle = "curious";
    } else if (["reading", "readingMoon", "writing", "running", "searching", "compact"].includes(action)) {
      browStyle = "focused";
    } else if (["pat", "patLeft", "tickle", "heartHug", "starCatchLeft", "starCatchRight"].includes(action)) {
      browStyle = "happy";
      if (action === "heartHug" || action === "tickle") mouthStyle = "cat";
      else if (action === "pat" || action === "patLeft") mouthStyle = "smile";
    } else if (action === "nose") {
      browStyle = "curious";
    } else if (action === "browInviteLeft" || action === "browInviteRight") {
      browStyle = "expectant";
      mouthStyle = "smile";
    }

    // 3. Render open-eye catchlights + real-time gaze tracking (zero destructive eye erasure!)
    if (!leftClosed) {
      drawOpenEyeAccents(ctx, lEye.sx, lEye.sy, close, effGazeX, effGazeY, eyeMode, tick, motion);
    }
    if (!rightClosed) {
      drawOpenEyeAccents(ctx, rEye.sx, rEye.sy, close, effGazeX, effGazeY, eyeMode, tick, motion);
    }

    // 3.5 Always-on warm peach-rose blush (drawn after eye accents so cheeks stay crisp!)
    if (action !== "doze" || frame < 10) {
      drawBlush(ctx, lCheek.sx, lCheek.sy, rCheek.sx, rCheek.sy, close, blushLevel, sulking);
    }

    // 4. Over-the-bangs anime pixel eyebrows (skip when curled sideways deep in doze)
    if (action !== "doze" || frame < 10) {
      drawBrows(ctx, lBrow.sx, lBrow.sy, rBrow.sx, rBrow.sy, close, browStyle);
    }

    // 5. Crisp expressive mouth
    if (mouthStyle !== "none") {
      drawMouth(ctx, mouth.sx, mouth.sy, close, mouthStyle);
    }

    // 6. Extra celebratory / personality pixel accents!
    if ((isBaseState && agentState === "succeeded") || isReunion) {
      const beat = motion ? Math.floor(tick / 260) % 4 : 0;
      const sparks = [
        [pt(-0.85, -0.78), "#ffe9a6", beat % 2 === 0 ? 1 : 0],
        [pt(0.85, -0.72), "#bce9e0", beat % 2 === 1 ? 1 : 0],
        [pt(-0.68, -0.95), "#ffd1df", beat === 1 || beat === 2 ? 1 : 0],
        [pt(0.66, -0.92), "#ffe9a6", beat === 0 || beat === 3 ? 1 : 0],
      ];
      for (const [pos, col, rad] of sparks) {
        if (pos.sy > 24 && pos.sy < 146) {
          if (rad) star(ctx, pos.sx, pos.sy, col, rad);
          else px(ctx, pos.sx, pos.sy, 1, 1, col);
        }
      }
    }
    if (isBaseState && agentState === "ended") {
      // Gentle drifting lavender-gold resting motes beside her temple.
      const beat = motion ? Math.floor(tick / 520) % 4 : 0;
      const mote = pt(0.84, -0.58 - beat * 0.05);
      if (mote.sy > 24 && mote.sy < 146) {
        if (beat === 1 || beat === 2) star(ctx, mote.sx, mote.sy, "#e6d8fa", 1);
        else px(ctx, mote.sx, mote.sy, 1, 1, "#fff2cf");
      }
    }
    if (sulking) {
      // Cute pulsing pastel-coral pout mark (💢) near upper-right temple
      const mark = pt(0.76, -0.72);
      const pulse = motion && Math.floor(tick / 320) % 2 === 0;
      const col = pulse ? "#ff9eab" : "#e8788c";
      const x = Math.round(mark.sx), y = Math.round(mark.sy);
      px(ctx, x - 2, y - 1, 2, 1, col);
      px(ctx, x - 1, y - 2, 1, 2, col);
      px(ctx, x + 1, y - 1, 2, 1, col);
      px(ctx, x + 1, y - 2, 1, 2, col);
      px(ctx, x - 2, y + 1, 2, 1, col);
      px(ctx, x - 1, y + 1, 1, 2, col);
      px(ctx, x + 1, y + 1, 2, 1, col);
      px(ctx, x + 1, y + 1, 1, 2, col);
    }
    if (action === "heartHug" && frame >= 14 && frame <= 26) {
      // Make the gifted ruby heart glow unmistakably in both full & close views!
      const heartSeat = pt(0, 0.42);
      drawHeartJewel(ctx, heartSeat.sx, heartSeat.sy, close);
    }
  }

  return { draw };
})();
