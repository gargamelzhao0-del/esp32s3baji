"use strict";

window.PixelBadge = (() => {
  const faceSide = 184,
    faceCenter = 92,
    faceRadius = 82,
    originX = 23,
    originY = (view) => (view === "close" ? 22 : 18),
    W = 138,
    H = 132;
  const blank = (w, h) => {
    const c = document.createElement("canvas");
    c.width = w;
    c.height = h;
    return c;
  };
  const facePlates = {};
  const faceShell = blank(faceSide, faceSide);
  const SKY_THEMES = {
    dawn: {
      stops: [[0,"424770"],[36,"625c86"],[66,"9b7893"],[86,"d698a0"],[102,"f2bcac"],[117,"fbe0c6"]],
      stars: 28, moon: false, sun: [148, 72],
      clouds: ["#f0c3c4", "#cfa0b0"],
      r1: "#8d7294", r2: "#6b5779", r3: "#584a69",
      dome: ["#4f4562","#6e5b7a","#8b728e","#be98a5","#d8b5b7","#544968","#b68e9b","#f4cd9e"],
      lake: "#9c7e96", lakeHi: "#b793a3", ripple: ["#836a87","#dfafb5"],
      pine1: ["#4b425e","#6d5870"], bank1: "#5e4e69", bank2: "#483f58", pine2: ["#3e384f","#624d64"],
      bloom: ["#8e7889","#f1bcc0"],
    },
    day: {
      stops: [[0,"4a78a8"],[36,"6598c4"],[66,"88b9dc"],[88,"b1d6ea"],[105,"d5ebf2"],[117,"e8f3ef"]],
      stars: 0, moon: false, sun: [148, 48],
      clouds: ["#f7fbff", "#d4e6f2"],
      r1: "#7f9ec0", r2: "#6685a9", r3: "#577294",
      dome: ["#4c627e","#667e9c","#7e99b5","#a9c0d1","#c9dbe4","#4a607a","#9ab4c8","#f7dfa4"],
      lake: "#7aa7c7", lakeHi: "#94bdd9", ripple: ["#6a95b6","#cde4ee"],
      pine1: ["#3f5a6d","#597c85"], bank1: "#536e7e", bank2: "#3e5466", pine2: ["#33495c","#4d6e78"],
      bloom: ["#6c8a8c","#f2c9cc"],
    },
    dusk: {
      stops: [[0,"25223c"],[38,"302943"],[66,"48405e"],[84,"705773"],[100,"bd8493"],[117,"deaaab"]],
      stars: 104, moon: true, sun: null,
      clouds: ["#ad8498", "#906f88"],
      r1: "#736080", r2: "#544660", r3: "#473e57",
      dome: ["#40384e","#5d4b67","#756179","#a58490","#c3a0a0","#453c55","#9c7885","#e4b596"],
      lake: "#745f78", lakeHi: "#826a80", ripple: ["#6a5874","#ab8391"],
      pine1: ["#3d374e","#57475b"], bank1: "#4b3e54", bank2: "#393246", pine2: ["#322e42","#534155"],
      bloom: ["#786674","#d2a0a4"],
    },
    night: {
      stops: [[0,"16172d"],[38,"1e203b"],[68,"2b2a4d"],[90,"3d3862"],[106,"544a75"],[117,"6b5c86"]],
      stars: 145, moon: true, sun: null,
      clouds: ["#4d4870", "#3a3759"],
      r1: "#433e63", r2: "#322e4d", r3: "#282640",
      dome: ["#26243b","#383452","#4b4466","#6e6082","#8d7d9c","#292640","#63577a","#f7d294"],
      lake: "#393757", lakeHi: "#484569", ripple: ["#2e2d4a","#756c99"],
      pine1: ["#222138","#383350"], bank1: "#2e2a44", bank2: "#211f34", pine2: ["#1b1a2e","#322d47"],
      bloom: ["#544d6e","#b69ec2"],
    },
  };
  function resolveSky(mode) {
    if (mode && SKY_THEMES[mode]) return mode;
    const h = new Date().getHours();
    if (h >= 6 && h < 10) return "dawn";
    if (h >= 10 && h < 17) return "day";
    if (h >= 17 && h < 20) return "dusk";
    return "night";
  }
  function rect(ctx, x, y, w, h, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
  }
  function shine(ctx, x, y, color, size = 2) {
    rect(ctx, x, y - size, 1, 2 * size + 1, color);
    rect(ctx, x - size, y, 2 * size + 1, 1, color);
  }
  function ridge(ctx, points, bottom, color) {
    ctx.fillStyle = color;
    for (let i = 1; i < points.length; i++) {
      const [a, b] = points[i - 1],
        [x, y] = points[i];
      for (let col = a; col < x; col++) {
        const top = Math.round(b + ((y - b) * (col - a)) / (x - a));
        ctx.fillRect(col, top, 1, bottom - top);
      }
    }
  }
  function pine(ctx, x, base, h, shade, light) {
    const top = base - h;
    rect(ctx, x, top, 1, h, shade);
    for (let tier = 1; tier <= 4; tier++) {
      const end = Math.round(h * (0.09 + 0.2 * tier));
      const length = Math.round(h * (0.13 + 0.04 * tier));
      for (let row = 0; row < length; row++) {
        const half = Math.floor((row + 1) * (0.45 + 0.075 * tier));
        rect(ctx, x - half, top + end - length + row, half * 2 + 1, 1, shade);
      }
      if (h > 16) rect(ctx, x - 1, top + end - length + 2, 1, 2, light);
    }
  }
  function buildPlate(themeName) {
    if (facePlates[themeName]) return facePlates[themeName];
    const plate = blank(faceSide, faceSide);
    const ctx = plate.getContext("2d");
    const theme = SKY_THEMES[themeName] || SKY_THEMES.dusk;
    const stops = theme.stops;
    for (let band = 1; band < stops.length; band++) {
      const [y0, low] = stops[band - 1],
        [y1, high] = stops[band];
      const rgb = [0, 2, 4].map((i) => [
        parseInt(low.slice(i, i + 2), 16),
        parseInt(high.slice(i, i + 2), 16),
      ]);
      for (let y = y0; y < y1; y++) {
        const t = (Math.floor((y - y0) / 3) * 3) / (y1 - y0);
        const color = rgb.map(([a, b]) => Math.round(a + (b - a) * t));
        rect(ctx, 0, y, faceSide, 1, "rgb(" + color.join(",") + ")");
      }
    }
    let seed = 8041;
    const random = () =>
      (seed = (Math.imul(1664525, seed) + 1013904223) >>> 0) / 4294967296;
    for (let i = 0; i < theme.stars; i++) {
      const x = Math.floor(random() * faceSide),
        y = 11 + Math.floor(random() * 82);
      if (y < 23 && Math.abs(x - faceCenter) < 35) continue;
      rect(ctx, x, y, 1, 1, ["#94839e", "#be9fab", "#e2d4e8"][i % 3]);
    }
    if (theme.stars > 20) {
      for (const [x, y] of [
        [42, 43],
        [32, 65],
        [148, 76],
        [124, 33],
      ])
        shine(ctx, x, y, "#e8c9ce", 1);
    }
    if (theme.moon) {
      // The moon has a lit limb and a darker underside, all on the display grid.
      for (let dy = -8; dy <= 8; dy++)
        for (let dx = -8; dx <= 8; dx++) {
          if (dx * dx + dy * dy <= 67 && (dx - 3) ** 2 + (dy + 3) ** 2 >= 60)
            rect(
              ctx,
              149 + dx,
              58 + dy,
              1,
              1,
              dy > 5 ? "#dbab99" : dx < -6 ? "#f2c59f" : "#f7dfb3",
            );
        }
    } else if (theme.sun) {
      const [sx, sy] = theme.sun;
      for (let dy = -7; dy <= 7; dy++)
        for (let dx = -7; dx <= 7; dx++) {
          const d2 = dx * dx + dy * dy;
          if (d2 <= 42)
            rect(ctx, sx + dx, sy + dy, 1, 1, d2 <= 20 ? "#fff6d6" : "#ffe1a8");
        }
    }
    for (const [x, y, w] of [
      [11, 81, 31],
      [24, 78, 12],
      [141, 83, 25],
      [153, 80, 16],
      [11, 89, 14],
      [130, 88, 14],
    ]) {
      rect(ctx, x, y, w, 1, theme.clouds[0]);
      rect(ctx, x + 3, y + 2, Math.ceil(w / 2), 1, theme.clouds[1]);
    }
    ridge(
      ctx,
      [
        [0, 97],
        [16, 93],
        [23, 96],
        [42, 80],
        [55, 90],
        [66, 83],
        [88, 100],
        [104, 89],
        [119, 97],
        [145, 79],
        [162, 94],
        [173, 88],
        [184, 91],
      ],
      119,
      theme.r1,
    );
    ridge(
      ctx,
      [
        [0, 109],
        [17, 103],
        [28, 106],
        [49, 93],
        [67, 105],
        [82, 102],
        [99, 112],
        [123, 96],
        [138, 100],
        [150, 89],
        [169, 105],
        [184, 98],
      ],
      122,
      theme.r2,
    );
    // The little dome and its two lit windows remain visible left of the dragon.
    const d = theme.dome;
    rect(ctx, 22, 93, 16, 12, d[0]);
    rect(ctx, 23, 89, 14, 5, d[1]);
    rect(ctx, 25, 86, 10, 4, d[2]);
    rect(ctx, 27, 85, 6, 2, d[3]);
    rect(ctx, 29, 82, 1, 3, d[4]);
    rect(ctx, 31, 87, 2, 5, d[5]);
    rect(ctx, 20, 94, 20, 2, d[6]);
    rect(ctx, 24, 99, 2, 3, d[7]);
    rect(ctx, 33, 99, 2, 3, d[7]);
    ridge(
      ctx,
      [
        [0, 112],
        [19, 103],
        [33, 105],
        [48, 101],
        [72, 116],
        [99, 110],
        [126, 113],
        [152, 106],
        [166, 100],
        [184, 106],
      ],
      121,
      theme.r3,
    );
    rect(ctx, 0, 115, faceSide, 28, theme.lake);
    rect(ctx, 0, 118, faceSide, 5, theme.lakeHi);
    for (let i = 0; i < 89; i++) {
      const x = Math.floor(random() * faceSide),
        y = 116 + Math.floor(random() * 19);
      rect(
        ctx,
        x,
        y,
        2 + Math.floor(random() * 7),
        1,
        i % 3 ? theme.ripple[0] : theme.ripple[1],
      );
    }
    for (const [x, y, h] of [
      [10, 127, 23],
      [18, 128, 16],
      [23, 123, 12],
      [34, 119, 9],
      [159, 119, 10],
      [168, 124, 17],
      [176, 128, 24],
    ])
      pine(ctx, x, y, h, theme.pine1[0], theme.pine1[1]);
    ridge(
      ctx,
      [
        [0, 122],
        [15, 126],
        [35, 128],
        [55, 135],
        [75, 138],
        [104, 139],
        [135, 135],
        [150, 129],
        [163, 129],
        [184, 119],
      ],
      177,
      theme.bank1,
    );
    ridge(
      ctx,
      [
        [0, 132],
        [12, 129],
        [28, 135],
        [48, 139],
        [80, 144],
        [112, 143],
        [143, 137],
        [169, 133],
        [184, 129],
      ],
      180,
      theme.bank2,
    );
    for (const [x, y, h] of [
      [12, 139, 22],
      [23, 136, 12],
      [29, 132, 9],
      [151, 131, 10],
      [163, 137, 14],
      [172, 139, 20],
    ])
      pine(ctx, x, y, h, theme.pine2[0], theme.pine2[1]);
    for (const [x, y] of [
      [36, 135],
      [40, 137],
      [144, 134],
      [150, 132],
    ]) {
      rect(ctx, x, y, 1, 3, theme.bloom[0]);
      rect(ctx, x, y - 1, 2, 1, theme.bloom[1]);
    }
    // Small stepped contact shadow where the skirt meets the near bank.
    rect(ctx, 76, 143, 33, 1, "#3e3247");
    rect(ctx, 69, 144, 45, 1, "#342c41");
    rect(ctx, 75, 145, 34, 1, "#2e283b");
    facePlates[themeName] = plate;
    return plate;
  }
  function buildShell() {
    const rimCtx = faceShell.getContext("2d");
    const rim = rimCtx.createImageData(faceSide, faceSide);
    const enamel = [
      "342d41",
      "66546d",
      "95869a",
      "bba9bb",
      "dbccce",
      "f5e4db",
      "876e88",
      "44384c",
    ].map((hex) => [0, 2, 4].map((i) => parseInt(hex.slice(i, i + 2), 16)));
    for (let y = 0; y < faceSide; y++)
      for (let x = 0; x < faceSide; x++) {
        const dx = x + 0.5 - faceCenter,
          dy = y + 0.5 - faceCenter,
          d = Math.hypot(dx, dy);
        if (d < faceRadius || d > 89.5) continue;
        const light = 0.48 * dx + 0.82 * dy;
        let tone;
        if (d > 88.5) tone = 0;
        else if (d > 86.9) tone = light < 0 ? 4 : 1;
        else if (d > 84.2) tone = light < -28 ? 5 : light < 18 ? 3 : 2;
        else if (d > 83) tone = light < -24 ? 2 : 6;
        else tone = 7;
        const k = (y * faceSide + x) * 4;
        rim.data.set(enamel[tone], k);
        rim.data[k + 3] = 255;
      }
    rimCtx.putImageData(rim, 0, 0);
  }
  buildPlate("dusk");
  buildShell();
  const disc = blank(faceSide, faceSide),
    mask = disc.getContext("2d");
  for (let y = 0; y < faceSide; y++)
    for (let x = 0; x < faceSide; x++) {
      if (Math.hypot(x + 0.5 - faceCenter, y + 0.5 - faceCenter) < faceRadius)
        mask.fillRect(x, y, 1, 1);
    }

  const letters = {
    ">": "100010001010100",
    _: "000000000000111",
    "%": "101001010100101",
    "~": "000010101000000",
    "-": "000000111000000",
    Q: "010101101111011",
    A: "010101111101101",
    B: "110101110101110",
    C: "011100100100011",
    D: "110101101101110",
    E: "111100110100111",
    F: "111100110100100",
    G: "011100101101011",
    H: "101101111101101",
    I: "111010010010111",
    K: "101101110101101",
    L: "100100100100111",
    M: "101111111101101",
    N: "101111111111101",
    O: "010101101101010",
    P: "110101110100100",
    R: "110101110101101",
    S: "011100010001110",
    T: "111010010010010",
    U: "101101101101111",
    V: "101101101101010",
    W: "101101111111101",
    Y: "101101010010010",
    X: "101101010101101",
    Z: "111001010100111",
    0: "111101101101111",
    1: "010110010010111",
    2: "110001010100111",
    3: "110001010001110",
    4: "101101111001001",
    5: "111100110001110",
    6: "011100110101010",
    7: "111001010010010",
    8: "010101010101010",
    9: "010101011001110",
    ":": "000010000010000",
    "?": "010101001010000",
    "!": "010010010000010",
    ".": "000000000000010",
    "+": "000010111010000",
    ",": "000000000010100",
    " ": "000000000000000",
  };
  function label(ctx, word, cx, y, color) {
    let x = Math.round(cx - (word.length * 4 - 1) / 2);
    for (const letter of word) {
      const glyph = letters[letter] || letters[" "];
      for (let p = 0; p < 15; p++)
        if (glyph[p] === "1")
          rect(ctx, x + (p % 3), y + Math.floor(p / 3), 1, 1, color);
      x += 4;
    }
  }
  // Native-grid props for states whose hands are free. Ink, main fabric,
  // shade and a sewn highlight keep their silhouettes readable on the dusk sky.
  const agentMarks = {
    working: { color: "#f0c573", shade: "#ac795e", rows: [
      ".....kkk.....", "...kkhhakk...", "..kahhaaask..", "..khaaaaask..",
      "..kaakakask..", "...kaakask...", "...kskkksk...",
      "....ksssk....", "....khhhk....", "....ksssk....", ".....kkk.....",
    ] },
    waiting: { color: "#b1dfd4", shade: "#68a29e", rows: [
      "..kkkkkkkkk..", ".kahhhhhaaak.", "kaaaaaaaahask", "kaaaakaaakask",
      "kaaakkaaakask", "kaakkkkkkkask", "kaaakkaaaaask", ".kssaksssssk.",
      "..kkasskkkk..", "...kask......", "...ksk.......", "...kk........",
    ] },
    succeeded: { color: "#9ed7ab", shade: "#629385", rows: [
      "....kkkkk....", "...khaahhk...", "..khaaaaakk..", ".khaaaaakkssk",
      ".kakaaakkassk", ".kakkakkaassk", "..kakkkaassk.", "..kaakaaassk.",
      "...kassssk...", "...kskkksk...", "..kaak.ksak..", "..kkk...kkk..",
    ] },
    ended: { color: "#cbb8df", shade: "#9484ae", rows: [
      "..kk.........", "..khkkkk.....", "..khaaaakkk..", "..khaahaaask.",
      "..khaaaahask.", "..khkkkaassk.", "..khk..kkkk..", "..khk........",
      "..khk........", "..khk........", ".ksssk.......", ".kkkkk.......",
    ] },
    limited: { color: "#ffd994", shade: "#b18870", rows: [
      ".............", ".kkkkkkkkkkk.", "khhaassaaassk", "kaassaaassaak",
      "kassaaassaaak", ".kkkkkkkkkkk.", "...ksk.ksk...", "...ksk.ksk...",
      "...ksk.ksk...", "..ksssksssk..", "..kkkkkkkkk..",
    ] },
    cancelled: { color: "#e7a49a", shade: "#ad767f", rows: [
      "....kkkkk....", "...kahhhak...", "..kaaaaaask..", ".kaaaaaaaask.",
      ".kaakkkkaask.", ".kaakhhkaask.", ".kaakhhkaask.", ".kaakkkkaask.",
      "..kaaaaassk..", "...kassssk...", "....kkkkk....",
    ] },
    error: { color: "#ffb2a2", shade: "#c48185", rows: [
      "......k......", ".....khk.....", ".....kak.....", "....kaask....",
      "....kaksk....", "...kaakask...", "...kaakask...", "..kaaaaassk..",
      "..kaaakaask..", ".kaaaaaaassk.", ".kkkkkkkkkkk.",
    ] },
  };
  // Redesigned 19x19 glowing enamel-pin status medallions (enhanced mode).
  // Outer border uses #342942, inner emblem keyline uses #453848 for monochrome distinctiveness.
  const enhancedAgentMarks = {
    working: {
      rim: "#f7cf73", bg: "#27203a", color: "#ffe68a", shade: "#cf934a",
      rows: [
        "h...kkkkk...h", "..kkhaaaakk..", ".khaaahhaaak.", ".khaahhaaaak.",
        ".kaaaaaasssk.", ".kaahkaasssk.", "..kakkkaask..", "...kkakskk...",
        "...ksssssk...", "...khhhhhk...", "...ksssssk...", "....ksssk....",
        ".....kkk.....",
      ],
    },
    waiting: {
      rim: "#7de3cd", bg: "#1d2d36", color: "#b7f5e5", shade: "#5ca69f",
      rows: [
        ".....kkk.....", "....kahak....", ".h.khaaask.h.", "h.khaaaaask.h",
        "..khaaaaask..", "..khaaaaask..", ".khaaaaaaask.", ".khaaaaaassk.",
        "khhhaaaaaassk", "ksssssssssssk", ".kkkkkkkkkkk.", "....khhsk....",
        ".....kkk.....",
      ],
    },
    succeeded: {
      rim: "#86e8a6", bg: "#1d312c", color: "#b2f7c4", shade: "#52a87b",
      rows: [
        "..h..........", ".hhh.....kkk.", "..h.....khahk", ".......khaask",
        "......khaask.", ".kkk.khaask..", "khahkhaask...", "khaaaaaask...",
        ".kaaaaask....", "..kaaaask....", "...kaask.....", "....kak......",
        ".....k.......",
      ],
    },
    ended: {
      rim: "#ccb4ee", bg: "#27213c", color: "#e6d8fa", shade: "#987fc0",
      rows: [
        "....kkkk.....", "..kkhaaak.h..", ".khaaakk.hhh.", ".khaak....h..",
        "khaak........", "khaak...h....", "khaak........", "kaask........",
        ".kaask...kk..", ".kaasskkhaak.", "..kaaaaaaask.", "...kssssssk..",
        "....kkkkkk...",
      ],
    },
    limited: {
      rim: "#f5bd6e", bg: "#312433", color: "#ffe19e", shade: "#c4804a",
      rows: [
        ".kkkkkkkkkkk.", ".khhhhhhhhhk.", ".kkkkkkkkkkk.", "..khaaasssk..",
        "..k.kaaaak.k.", "...k.khhk.k..", "....kkhk.k...", "...k..hk..k..",
        "..k..khaak.k.", "..k.khaaaskk.", ".kkkkkkkkkkk.", ".ksssssssssk.",
        ".kkkkkkkkkkk.",
      ],
    },
    cancelled: {
      rim: "#f29b94", bg: "#332130", color: "#ffc0b8", shade: "#bd6770",
      rows: [
        "...kkkkkkk...", "..khhhaaaak..", ".khaakkkkaak.", "khakk...kkaak",
        "khakha...kaak", "kaak.ha..kask", "kaak..ha.kask", "kaak...hakask",
        "kaak....haask", "kassk...kkask", ".kasskkkassk.", "..ksssssssk..",
        "...kkkkkkk...",
      ],
    },
    error: {
      rim: "#ff7a88", bg: "#381e2c", color: "#ffb4b8", shade: "#c94f63",
      rows: [
        "......k......", ".....khk.....", "....khaak....", "....khhak....",
        "...kakhkak...", "...kakhkak...", "..kaakhkaak..", "..kaakhkaak..",
        ".kaaaakaaask.", ".kaaakhkaask.", "kaaaaakaaaask", "ksssssssssssk",
        "kkkkkkkkkkkkk",
      ],
    },
  };
  const medallionFrame = [
    "....ooooooooooo....",
    "..oorrrrrrrrrrroo..",
    ".orggdddddddddddor.",
    ".orgddddddddddddro.",
    "ordddddddddddddddro",
    "ordddddddddddddddro",
    "ordddddddddddddddro",
    "ordddddddddddddddro",
    "ordddddddddddddddro",
    "ordddddddddddddddro",
    "ordddddddddddddddro",
    "ordddddddddddddddro",
    "ordddddddddddddddro",
    "ordddddddddddddddro",
    "ordddddddddddddddro",
    ".ordddddddddddddro.",
    ".orrrrrrrrrrrrrrro.",
    "..oorrrrrrrrrrroo..",
    "....ooooooooooo....",
  ];
  function agentMark(ctx, state, view, clip, lit, legacy, skyName, tick = 0, motion = false) {
    if (legacy) {
      const mark = agentMarks[state];
      if (!mark) return;
      let x = 32, y = 47;
      if (view === "close") {
        x = clip?.closePan ? 137 : 15;
        y = clip?.closePan ? 36 : 75;
      }
      const colors = { k: "#453848", a: mark.color, s: mark.shade, h: lit ? "#fff8dc" : "#f5ece4" };
      mark.rows.forEach((row, j) => {
        for (let i = 0; i < row.length; i++) {
          if (row[i] !== ".") rect(ctx, x + i, y + j, 1, 1, colors[row[i]]);
        }
      });
      return;
    }
    const mark = enhancedAgentMarks[state];
    if (!mark) return;
    let x = 28, y = 44;
    if (view === "close") {
      x = clip?.closePan ? 132 : 17;
      y = clip?.closePan ? 36 : 63;
    }
    const bob = motion && Math.sin(tick / 620) > 0.35 ? -1 : 0;
    const pulse = motion && (state === "waiting" || state === "error" || state === "succeeded") &&
      Math.floor(tick / 420) % 2 === 0;
    const rimCol = lit || pulse ? "#fff6d8" : mark.rim;
    const frameColors = {
      o: "#342942",
      r: rimCol,
      g: "#fff8e8",
      d: mark.bg,
    };
    const by = y + bob;
    // Soft pixel drop shadow on bright skies so medallion lifts cleanly off dawn/day clouds.
    if (skyName === "day" || skyName === "dawn") {
      rect(ctx, x + 3, by + 18, 13, 2, "rgba(38,31,56,0.28)");
    }
    medallionFrame.forEach((row, j) => {
      for (let i = 0; i < row.length; i++) {
        const col = frameColors[row[i]];
        if (col) rect(ctx, x + i, by + j, 1, 1, col);
      }
    });
    const innerColors = {
      k: "#453848",
      a: mark.color,
      s: mark.shade,
      h: lit || pulse ? "#ffffff" : "#fff7dc",
    };
    mark.rows.forEach((row, j) => {
      for (let i = 0; i < row.length; i++) {
        const col = innerColors[row[i]];
        if (col) rect(ctx, x + 3 + i, by + 3 + j, 1, 1, col);
      }
    });
    // Tiny twinkling starlet on top-right rim when newly activated or in celebratory pulse.
    if (motion && (lit || (state === "succeeded" && pulse) || (state === "working" && Math.floor(tick / 520) % 3 === 0))) {
      shine(ctx, x + 17, by + 1, "#fff6d1", 1);
    }
  }

  function drawAmbientSky(ctx, themeName, tick, motion) {
    if (!motion) return;
    // 8 staggered twinkling stars in twilight/night/dawn skies.
    if (themeName !== "day") {
      const twinkles = [
        [42, 43, 0, "#eed1d3"],
        [124, 33, 2, "#f3e2c8"],
        [32, 65, 5, "#dcd0ee"],
        [148, 76, 3, "#eed1d3"],
        [58, 30, 6, "#d9ebf0"],
        [136, 44, 1, "#fff2cf"],
        [24, 52, 4, "#e6d2e8"],
        [160, 66, 7, "#d9c8e6"],
      ];
      const step = Math.floor(tick / 380);
      for (const [sx, sy, off, col] of twinkles) {
        const p = (step + off) % 8;
        if (p === 1 || p === 2) shine(ctx, sx, sy, col, p === 2 ? 2 : 1);
      }
    }
    // Periodic pixel shooting star across the zenith (dusk & night).
    if (themeName === "night" || themeName === "dusk") {
      const cycle = tick % 11500;
      if (cycle >= 6200 && cycle < 6950) {
        const t = (cycle - 6200) / 750;
        const sx = Math.round(52 + t * 54);
        const sy = Math.round(28 + t * 18);
        rect(ctx, sx, sy, 2, 1, "#fff9df");
        rect(ctx, sx - 3, sy - 1, 3, 1, "#e7d2b4");
        rect(ctx, sx - 6, sy - 2, 3, 1, "#9b8aa8");
      }
    }
    // Warm breathing observatory windows.
    const glow = Math.floor(tick / 750) % 4;
    if (glow === 1 || glow === 2) {
      const winCol = themeName === "night" ? "#ffe9ad" : "#f4d2a8";
      rect(ctx, 24, 99, 2, 3, winCol);
      rect(ctx, 33, 99, 2, 3, winCol);
    }
    // Gentle lake shimmer ripples.
    const rip = Math.floor(tick / 550) % 6;
    const rCol = themeName === "day" ? "#eff7fa" : themeName === "night" ? "#8b7eb0" : "#cfa3b2";
    rect(ctx, 18 + rip * 2, 121, 5, 1, rCol);
    rect(ctx, 146 - rip * 2, 123, 6, 1, rCol);
    // Floating ambient golden fireflies near the twilight/night pines.
    if (themeName === "night" || themeName === "dusk") {
      for (let i = 0; i < 3; i++) {
        const phase = tick * 0.0011 + i * 2.1;
        const fx = Math.round((i === 1 ? 156 : 26 + i * 6) + Math.sin(phase) * 7);
        const fy = Math.round(118 + i * 6 + Math.cos(phase * 1.3) * 4);
        const bright = Math.sin(phase * 2.2) > -0.2;
        if (bright) rect(ctx, fx, fy, 1, 1, "#fff2a8");
      }
    } else {
      // Gentle drifting pixel cloudlets in dawn/day.
      const drift = Math.floor((tick / 420) % 28) - 14;
      const cCol = themeName === "day" ? "#ffffff" : "#fae0dc";
      rect(ctx, 36 + drift, 42, 11, 2, cCol);
      rect(ctx, 38 + drift, 40, 6, 2, cCol);
      rect(ctx, 132 - Math.floor(drift * 0.6), 36, 9, 2, cCol);
    }
  }

  function drawCranes(ctx, helpers, tick, motion) {
    const count = Math.min(2, Math.max(0, helpers | 0));
    if (!count) return;
    const flap = motion ? Math.floor(tick / 220) % 2 : 0;
    const spots = [
      { bx: 30, by: 62, phase: 0, dir: 1 },
      { bx: 151, by: 72, phase: 1.8, dir: -1 },
    ];
    for (let i = 0; i < count; i++) {
      const s = spots[i];
      const t = motion ? tick * 0.0018 + s.phase : s.phase;
      const x = Math.round(s.bx + Math.sin(t) * 6);
      const y = Math.round(s.by + Math.cos(t * 1.4) * 3);
      // Crisp 9x6 origami paper crane with flapping pixel wings!
      rect(ctx, x - 2, y, 5, 1, "#f7eef8");
      rect(ctx, x - 1, y + 1, 3, 1, "#d9c8e6");
      rect(ctx, x + (s.dir > 0 ? 3 : -3), y - 1, 1, 1, "#ffe7aa"); // beak
      if (flap === 0) {
        rect(ctx, x - 3, y - 2, 3, 2, "#fff7fb");
        rect(ctx, x + 1, y - 2, 3, 2, "#e8dbf2");
        rect(ctx, x - 2, y - 3, 2, 1, "#7b6c8c");
      } else {
        rect(ctx, x - 3, y + 1, 3, 2, "#e8dbf2");
        rect(ctx, x + 1, y + 1, 3, 2, "#fff7fb");
      }
    }
  }

  function drawStatusHalo(ctx, agentState, telemetryMode, sulking, tick, motion) {
    if (telemetryMode === "OFF" || telemetryMode === "SYNC") return;
    let color = null;
    let pulse = false;
    if (sulking) {
      color = "#ef8ca6";
      pulse = true;
    } else if (agentState === "waiting") {
      color = "#f6c46d";
      pulse = true;
    } else if (agentState === "error") {
      color = "#f28588";
      pulse = true;
    } else if (agentState === "succeeded") {
      color = "#96e3ab";
      pulse = true;
    } else if (agentState === "limited") {
      color = "#cfa068";
    } else if (agentState === "ended") {
      color = "#c8b5e3";
    } else if (agentState !== "idle") {
      color = "#7bcbb9";
    }
    if (!color) return;
    const dim = pulse && motion && Math.floor(tick / 480) % 2 === 1;
    ctx.save();
    ctx.globalAlpha = dim ? 0.45 : 0.9;
    // Two crisp symmetric curved temple-arcs along the upper-left and upper-right bezel,
    // staying completely clear of the top status header (x=60..124, y=16..20) and marks.
    for (const [startDeg, endDeg] of [[-155, -126], [-54, -25]]) {
      for (let deg = startDeg; deg <= endDeg; deg += 1.4) {
        const rad = (deg * Math.PI) / 180;
        const x = Math.round(faceCenter + Math.cos(rad) * (faceRadius - 1.5));
        const y = Math.round(faceCenter + Math.sin(rad) * (faceRadius - 1.5));
        rect(ctx, x, y, 2, 1, color);
      }
    }
    ctx.restore();
  }

  // Native 12px Fusion Pixel glyphs, under the same OFL as the bundled font.
  const han = {
    剩: [1151, 1288, 1407, 1322, 1387, 1322, 1387, 1304, 1068, 1099, 1544],
    余: [32, 80, 396, 1787, 32, 32, 1022, 32, 292, 1571, 48],
    额: [1992, 319, 2021, 1118, 1363, 1356, 1395, 1374, 274, 658, 1118],
    度: [64, 2046, 274, 2046, 274, 498, 2, 1018, 274, 226, 1821],
    上: [32, 32, 32, 32, 992, 32, 32, 32, 32, 32, 2047],
    下: [2047, 32, 32, 32, 160, 288, 544, 32, 32, 32, 32],
    文: [16, 32, 2047, 260, 260, 136, 136, 80, 32, 216, 1799],
  };
  const numerals = {
    0: [6, 9, 9, 9, 9, 9, 6],
    1: [2, 6, 2, 2, 2, 2, 7],
    2: [6, 9, 1, 2, 4, 8, 15],
    3: [14, 1, 1, 6, 1, 1, 14],
    4: [2, 6, 10, 10, 15, 2, 2],
    5: [15, 8, 8, 14, 1, 1, 14],
    6: [6, 8, 8, 14, 9, 9, 6],
    7: [15, 1, 2, 2, 4, 4, 4],
    8: [6, 9, 9, 6, 9, 9, 6],
    9: [6, 9, 9, 7, 1, 1, 6],
    "%": [9, 9, 2, 2, 4, 9, 9],
    "-": [0, 0, 0, 14, 0, 0, 0],
    "~": [0, 0, 5, 10, 0, 0, 0],
  };
  function drawMiniGlyph(ctx, kind, x, y, color) {
    const pattern =
      kind === "bolt"
        ? ["..11.", ".11..", "1111.", "..11.", ".11..", "11..."]
        : ["11111", "1...1", "11111", "1...1", "11111", "....."];
    for (let j = 0; j < pattern.length; j++) {
      for (let i = 0; i < pattern[j].length; i++) {
        if (pattern[j][i] === "1") rect(ctx, x + i, y + j, 1, 1, color);
      }
    }
  }

  function instrument(ctx, telemetry, code, legacy = false) {
    const mint = "#a6ddc8",
      lilac = "#cec3e8";
    label(
      ctx,
      ">_ " + (code === "IDLE" ? "CODEX" : code) + " " + telemetry.mode,
      faceCenter,
      16,
      "#e2efe9",
    );
    if (legacy) {
      rect(ctx, 0, 149, faceSide, 35, "#252331");
      rect(ctx, 31, 149, 122, 1, "#615266");
      rect(ctx, 92, 152, 1, 13, "#494151");
      function legacyMeter(word, x, numberX, barX, value, color) {
        const left = x - word.length * 6;
        for (let i = 0; i < word.length; i++) {
          han[word[i]].forEach((bits, y) => {
            for (let dx = 0; dx < 12; dx++)
              if (bits & (1 << dx))
                rect(ctx, left + 12 * i + dx, 151 + y, 1, 1, "#b4c2c7");
          });
        }
        let pen = numberX - Math.floor((5 * value.text.length - 1) / 2);
        for (const ch of value.text) {
          numerals[ch].forEach((bits, y) => {
            for (let dx = 0; dx < 4; dx++)
              if (bits & (8 >> dx))
                rect(ctx, pen + dx, 163 + y, 1, 1, value.percent === null ? "#86969d" : color);
          });
          pen += 5;
        }
        rect(ctx, barX, 149, 36, 1, "#405059");
        if (value.percent !== null)
          rect(ctx, barX, 149, Math.round((36 * value.percent) / 100), 1, color);
        else
          for (let i = 2; i < 36; i += 5)
            rect(ctx, barX + i, 149, 1, 1, "#65747b");
      }
      legacyMeter("剩余额度", 68, 77, 49, telemetry.quota, mint);
      legacyMeter("上下文", 114, 107, 98, telemetry.context, lilac);
      return;
    }
    // Sleek rebalanced bottom bar (y=153..184): +4px taller character stage,
    // crisp icon + percentage + 3px readable capsule bars, zero bezel collision!
    rect(ctx, 0, 153, faceSide, 31, "#232130");
    rect(ctx, 34, 153, 116, 1, "#574a60");
    rect(ctx, 92, 156, 1, 14, "#453d50");
    function sleekMeter(glyph, centerX, barX, value, color) {
      const textW = value.text.length * 5 - 1;
      const totalW = 7 + textW;
      const startX = Math.round(centerX - totalW / 2);
      const tone = value.percent === null ? "#86969d" : color;
      drawMiniGlyph(ctx, glyph, startX, 156, tone);
      let pen = startX + 7;
      for (const ch of value.text) {
        numerals[ch].forEach((bits, y) => {
          for (let dx = 0; dx < 4; dx++)
            if (bits & (8 >> dx)) rect(ctx, pen + dx, 156 + y, 1, 1, tone);
        });
        pen += 5;
      }
      // Crisp 3px rounded-cap progress capsule bar!
      const barW = 34;
      rect(ctx, barX + 1, 165, barW - 2, 3, "#363c4d");
      rect(ctx, barX, 166, barW, 1, "#363c4d");
      if (value.percent !== null) {
        const fill = Math.round((barW * value.percent) / 100);
        if (fill > 0) {
          rect(ctx, barX, 166, fill, 1, color);
          if (fill > 2) rect(ctx, barX + 1, 165, fill - 2, 3, color);
          else rect(ctx, barX, 165, fill, 3, color);
        }
      } else {
        for (let i = 2; i < barW - 2; i += 5) rect(ctx, barX + i, 166, 2, 1, "#687680");
      }
    }
    sleekMeter("bolt", 71, 53, telemetry.quota, mint);
    sleekMeter("ctx", 113, 97, telemetry.context, lilac);
  }
  const iconInk = {
    o: "#45384c", d: "#51465f", n: "#32465a", v: "#aa92bc",
    m: "#69a6a8", t: "#bce3d5", w: "#fff1de", g: "#e4ad62",
    p: "#efc5b6", r: "#d98196", b: "#a4c9df", s: "#829ab9", c: "#c8e0e8",
  };
  const icons = {
    keys: [
      "..ooooooooooo.",
      ".ottmtttttttmo",
      ".ondnnnnnnnndo",
      ".onwnnnnnnnndo",
      ".onnwntggnnndo",
      ".onwnnnnnnnndo",
      ".ondnnnnnnnndo",
      ".ommmmmmmmmmmo",
      "..omomoowgmoo.",
      "...ooooooooo..",
    ],
    lens: [
      "....ooooo.....",
      "..oogwwwgoo...",
      ".ogwtmmmtwgo..",
      ".owtwtttmwgo..",
      ".ogtmtttmtgo..",
      ".ogtmmmmtwgo..",
      "..ogwtttwgo...",
      "...oogggoodo..",
      ".....oooodrdo.",
      ".........odpdo",
      "..........odro",
      "...........oo.",
    ],
    cheek: [
      "...ooooooo.....",
      "..owwwwwpwo....",
      ".owwwwwwwpwo...",
      ".owonwwonwwo...",
      ".owrrwwwwrro...",
      "..opwwwwwwo..oo",
      "...ooooooo..opo",
      ".........oooppo",
      "........oppppo.",
      ".........oooo..",
    ],
    pillow: [
      "..........ooo..",
      "...ooo...occco.",
      "..occco.ooccbo.",
      ".occbccoobggbbo",
      "occbbbbbbgbbbbo",
      "obbbbbbbbggbsso",
      ".osbbbbbbbssso.",
      "..osssbbbssso..",
      "...ooossssoo...",
      "......oooo.....",
    ],
    wake: [
      ".....oggo.....",
      "....ogwwgo....",
      "...ogwwgggo...",
      "..ogwwwgggo..m",
      "..ogwwwgggo..t",
      "..owwwggggo...",
      ".ogggggggggo..",
      ".ooooooooooo..",
      ".....oggo.....",
      "......oo......",
    ],
    book: [
      ".ooooo..ooooo.",
      "odwwwwoodgggvo",
      "odwwwwwowgggvo",
      "odwvvwwowggwvo",
      "odwwwwwowvwgvo",
      "odwvvwwowgggvo",
      "odwwwwwowwwgvo",
      "odwwwwwowwwvvo",
      "odooowwowooovo",
      ".ommmooovvvvo.",
      "..oooo.ooooo..",
    ],
    hand: [
      ".....oo.......",
      "....oppoo.....",
      "....opoppo....",
      "..ooopoppooo..",
      ".opopppppoppo.",
      ".opopwppppppo.",
      "..opppppppppo.",
      "oo.oppppppppo.",
      "opoopppppppo..",
      ".opppppppppo..",
      "..opppppppo...",
      "...otmmmmo....",
      "...ooooooo....",
    ],
    brush: [
      "..ttt...m.....",
      ".m...t........",
      ".....oo..oo...",
      "....oppooppo..",
      "...oppooppo...",
      "..opppoppopo..",
      ".opppppppoppo.",
      ".opwppppppppo.",
      "..oppppppppo..",
      "...oppppppo...",
      "....otmmmo....",
      ".....oooo.....",
    ],
    candy: [
      "oo.........oo",
      "omoo.....oomo",
      "omwvooooomtmo",
      ".otowgwwgowto",
      "..owggwgggo..",
      "..ogggggpgo..",
      "..ogggwpgoo..",
      ".omovggoovtmo",
      "omwmooooomwmo",
      "omoo.....oomo",
      "oo.........oo",
    ],
    bubble: [
      "....ooooo....",
      "..ootwwtmoo..",
      ".otwwttvvvvo.",
      ".owwttvvvvto.",
      "otwvvvvvvvpto",
      "otvvvvggvvvpo",
      "omvvvggwgvvpo",
      "omvvvvggvvvpo",
      ".ovvvvvvvpto.",
      ".ovvvvvvptto.",
      "..oomtttmoo..",
      "....ooooo....",
    ],
    nose: [
      ".....ooooo....",
      "...oowwwwwoo..",
      "..owwwwwwwwwo.",
      ".owwdowwwodwwo",
      ".owwrrwwwrrwwo",
      "..owwwogowwwo.",
      "...oowwwwwwo..",
      ".....oooooo...",
      ".........t....",
      "........twt...",
      ".........t....",
    ],
    firefly: [
      ".oo.......oo.",
      "omto..g..otmo",
      "otwoggwggoowo",
      ".ooogwwwgoo..",
      "....ggwgg....",
      "...ggwwwgg...",
      "..ogwwwwwgo..",
      "...ogwwwgo...",
      "....ogwgo....",
      ".....ogo.....",
      "......o......",
    ],
    catch: [
      "......g.......",
      "....ggwgg.....",
      ".....gwg......",
      "......g.......",
      ".oo........oo.",
      ".opo......opo.",
      ".oppo....oppo.",
      "..oppooooppo..",
      "..opppwppppo..",
      "...oppppppo...",
      "....otmmmo....",
      "....oooooo....",
    ],
    recall: [
      ".......g......",
      ".....ggwgg....",
      "......gwg.....",
      "...oo..g......",
      "..ommo........",
      ".ommmo......o.",
      "ommmmmo....omo",
      "..ommo....otmo",
      "...ommooootmo.",
      "....otttttmo..",
      ".....oooooo...",
    ],
  };

  function paintIcon(canvas, name) {
    const rows = icons[name];
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    const left = Math.floor((canvas.width - Math.max(...rows.map(row => row.length))) / 2);
    const top = Math.floor((canvas.height - rows.length) / 2);
    rows.forEach((row, y) => [...row].forEach((pixel, x) => {
      if (iconInk[pixel]) rect(ctx, left+x, top+y, 1, 1, iconInk[pixel]);
    }));
    canvas.dataset.icon = name;
  }
  for (const canvas of document.querySelectorAll("[data-icon]"))
    paintIcon(canvas, canvas.dataset.icon);

  const TOP_CLIP_CLIPS = new Set([
    "feed", "heartHug", "succeeded", "play", "bubblePop",
  ]);
  const SLEEP_CLIPS = new Set([
    "doze", "peekLeft", "peekRight", "wakeLeft", "wakeRight",
  ]);

  class Display {
    static setButtonIcon(canvas, name) {
      if (canvas.dataset.icon !== name) paintIcon(canvas, name);
    }

    constructor(canvas) {
      this.canvas = canvas;
      this.ctx = canvas.getContext("2d");
      this.buffer = blank(faceSide, faceSide);
      this.paint = this.buffer.getContext("2d");
      this.zoom = 0;
      this.overlay = null;
      this.shift = { dx: 0, dy: 0 };
    }
    computeShift(view, action, breatheY, legacy) {
      if (legacy || SLEEP_CLIPS.has(action)) return { dx: 0, dy: 0 };
      let dx = 0;
      let dy = breatheY || 0;
      if (view === "close") {
        if (TOP_CLIP_CLIPS.has(action)) dy += 3;
        // Tuck feed/bubblePop's left tile border behind the left bezel & clear the moon!
        if (action === "feed" || action === "bubblePop") dx -= 9;
      }
      return { dx, dy };
    }
    resize(space) {
      const dpr = Math.min(window.devicePixelRatio || 1, 3),
        room = Math.min(555, Math.max(140, space - 22));
      const zoom = Math.max(2, Math.floor((room * dpr) / faceSide)),
        css = Math.min(room, (faceSide * zoom) / dpr);
      this.canvas.style.width = css + "px";
      if (zoom === this.zoom) return;
      this.zoom = zoom;
      this.canvas.width = this.canvas.height = faceSide * zoom;
      const layer = blank(faceSide * zoom, faceSide * zoom),
        g = layer.getContext("2d");
      // Gentler retro LCD mesh so pure white hair stays luminous when grid is enabled.
      const strength = zoom <= 2 ? 0.08 : zoom === 3 ? 0.1 : 0.12;
      g.fillStyle = `rgba(149,129,155,${strength})`;
      g.beginPath();
      for (let n = 0; n < faceSide * zoom; n += zoom) {
        g.rect(n, 0, 1, faceSide * zoom);
        g.rect(0, n, faceSide * zoom, 1);
      }
      g.fill();
      g.globalCompositeOperation = "destination-in";
      g.imageSmoothingEnabled = false;
      g.drawImage(disc, 0, 0, layer.width, layer.height);
      g.clearRect(0, 153 * zoom, layer.width, layer.height);
      g.clearRect(0, 0, layer.width, 22 * zoom);
      this.overlay = layer;
    }
    draw({
      sheet,
      hands,
      clip,
      frame,
      view,
      grid,
      code,
      agentState,
      telemetry,
      tick,
      motion,
      action,
      sparks,
      starToy,
      contact,
      offeredFringe = 0,
      offeredBubble = false,
      burstOrigin = null,
      emotes = [],
      legacy = false,
      skyMode = "auto",
      helpers = 0,
      gazeX = 0,
      gazeY = 0,
      breatheY = 0,
      sulkPhase = null,
      reunion = false,
      bondLevel = 0,
    }) {
      if (!this.zoom) return;
      const ctx = this.paint;
      const skyName = legacy ? "dusk" : resolveSky(skyMode);
      const plate = buildPlate(skyName);
      this.shift = this.computeShift(view, action, motion ? breatheY : 0, legacy);
      ctx.clearRect(0, 0, faceSide, faceSide);
      ctx.drawImage(plate, 0, 0);
      if (legacy) {
        if (motion) {
          const phase = Math.floor(tick / 420) % 8;
          if (phase === 1 || phase === 2)
            shine(ctx, 42, 43, "#eed1d3", phase === 1 ? 1 : 2);
        }
      } else {
        drawAmbientSky(ctx, skyName, tick, motion);
        drawCranes(ctx, helpers, tick, motion);
      }
      if (telemetry.mode !== "OFF" && telemetry.mode !== "SYNC") {
        const lit = motion && emotes.some(e => e.zone === "status" && e.kind === agentState && e.age < 480);
        agentMark(ctx, agentState, view, clip, lit, legacy, skyName, tick, motion);
      }
      if (sheet) {
        const tile = frame + (clip.offset || 0);
        const r =
          Math.floor(tile / 8) +
          (view === "close" && !clip.paired ? Math.ceil(clip.frames / 8) : 0);
        const column = (tile % 8) + (clip.paired && view === "close" ? 8 : 0);
        const drawX = originX + this.shift.dx;
        const drawY = originY(view) + this.shift.dy;
        ctx.drawImage(sheet, column * W, r * H, W, H, drawX, drawY, W, H);
        if (hands) {
          const row =
            Math.floor(hands.frame / 8) +
            (view === "close" ? Math.ceil(hands.clip.frames / 8) : 0);
          ctx.drawImage(
            hands.sheet,
            (hands.frame % 8) * W,
            row * H,
            W,
            H,
            drawX,
            drawY,
            W,
            H,
          );
        }
        if (!legacy && window.FaceFX) {
          window.FaceFX.draw(ctx, this, {
            clip,
            frame,
            view,
            action,
            agentState,
            tick,
            motion,
            gazeX,
            gazeY,
            sulkPhase,
            reunion,
            bondLevel,
          });
        }
        const cushion = NapProp.position(this, clip, frame, view, action);
        if (cushion) {
          NapProp.pillow(ctx, cushion, contact, motion);
          // Keep the resting hands and lower cheek in front of the cushion.
          ctx.drawImage(sheet, (column + 8) * W, r * H, W, H, drawX, drawY, W, H);
        }
        NapProp.sleepMarks(ctx, action, frame, view, motion);
        if (burstOrigin) this.sugarBurst(ctx, clip, frame, view, burstOrigin);
        this.expression(ctx, clip, frame, view, action, motion, sparks);
        if (offeredFringe || offeredBubble)
          this.offerMark(ctx, clip, frame, view, offeredFringe, offeredBubble, motion ? Math.floor(tick/420)%4 : 0, legacy);
        this.emotes(ctx, clip, frame, view, action, emotes, motion, legacy);
      }
      if (starToy || contact) {
        ctx.save();
        ctx.beginPath();
        ctx.rect(0, 23, faceSide, legacy ? 126 : 130);
        ctx.clip();
        starToy?.draw(ctx);
        if (contact) this.contactMark(ctx, contact, motion);
        ctx.restore();
      }
      instrument(ctx, telemetry, code, legacy);
      if (!legacy) {
        drawStatusHalo(ctx, agentState, telemetry.mode, Boolean(sulkPhase), tick, motion);
      }
      ctx.globalCompositeOperation = "destination-in";
      ctx.drawImage(disc, 0, 0);
      ctx.globalCompositeOperation = "source-over";
      ctx.drawImage(faceShell, 0, 0);
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      this.ctx.imageSmoothingEnabled = false;
      this.ctx.drawImage(
        this.buffer,
        0,
        0,
        this.canvas.width,
        this.canvas.height,
      );
      if (grid) {
        this.ctx.globalCompositeOperation = "multiply";
        this.ctx.drawImage(this.overlay, 0, 0);
        this.ctx.globalCompositeOperation = "source-over";
      }
    }
    facePoint(view, clip, frame, x, y) {
      const [ox, oy] =
        view === "full" ? [28, 12] : clip.closeOrigin || [113, 34.5];
      const step = view === "full" ? 4 : 2.75;
      const sxShift = clip?.cushion ? 0 : this.shift.dx;
      const syShift = clip?.cushion ? 0 : this.shift.dy;
      return {
        sx:
          originX +
          sxShift +
          (x - ox) / step -
          (view === "close" ? clip.closePan?.[frame] || 0 : 0),
        sy: originY(view) + syShift + (y - oy) / step,
      };
    }
    contactMark(ctx, { sx, sy, part, age, phase }, motion) {
      if (
        !Number.isFinite(sx) ||
        !Number.isFinite(sy) ||
        !part ||
        part === "outside" || part === "pillow"
      )
        return;
      const x = Math.round(sx),
        y = Math.round(sy);
      const pressed = phase === "down";
      if (!pressed && (age >= 260 || !motion)) return;
      // Marks start on the touched pixel. Leave the middle clear for the feature being touched.
      const advance = motion ? Math.min(3, Math.floor(age / 55)) : 0;
      const r = pressed ? (advance ? 3 : 4) : 3 + advance;
      const tool = [
        "book",
        "palmTap",
        "keyChime",
        "lensFind",
        "bubblePop",
      ].includes(part);
      const light = tool ? "#d9efd5" : "#ffe0cf";
      const ink = tool ? "#536e70" : "#8a576d";
      if (pressed) {
        rect(ctx, x - r - 1, y, 2, 1, ink);
        rect(ctx, x - r, y - 1, 1, 1, light);
        rect(ctx, x + r, y, 2, 1, ink);
        rect(ctx, x + r, y - 1, 1, 1, light);
      } else {
        for (const sign of [-1, 1]) {
          rect(ctx, x + sign * r, y - 1 - advance, 1, 1, light);
          if (advance < 3)
            rect(ctx, x + sign * (r + 1), y - advance, 1, 1, ink);
        }
      }
    }
    offerMark(ctx, clip, frame, view, fringe, bubble, beat, legacy = false) {
      if (bubble && clip.bubbles?.[frame]) {
        const [bx, by, r] = clip.bubbles[frame];
        // Follow the moving sugar shell in source space, including the close camera pan.
        const {sx, sy} = this.facePoint(view, clip, frame, bx-r*.68, by-r*.70);
        const x=Math.round(sx), y=Math.round(sy);
        rect(ctx,x-1,y-1,4,2,"#61516e");
        rect(ctx,x-2,y,2,3,"#61516e");
        rect(ctx,x,y-1,3,1,"#ffedae");
        rect(ctx,x-1,y,2,1,"#fff7df");
        if (beat === 1 || beat === 2) rect(ctx,x-2,y+1,1,2,"#bfe8df");
      } else if (fringe) {
        const [fx,fy,nx,ny] = clip.anchors[frame];
        const {sx,sy}=this.facePoint(view,clip,frame,fx+fringe*(ny-fy)*.48,fy-fringe*(nx-fx)*.48);
        const x=Math.round(sx), y=Math.round(sy);
        if (legacy) {
          rect(ctx,x-1,y-1,3,1,"#68556e");
          rect(ctx,x-1,y,2,1,"#f6d58f");
          const dx=fringe*(beat===1 ? 4 : 3);
          rect(ctx,x+dx,y-3,1,2,"#68556e");
          rect(ctx,x+dx+fringe,y-4,1,2,"#ffeabc");
        } else {
          // Crisp twinkling golden-mint star beside the offered forehead lock!
          const big = beat === 1 || beat === 2;
          const ox = x + fringe * 5, oy = y - 4;
          shine(ctx, ox, oy, "#594566", big ? 2 : 1);
          shine(ctx, ox, oy, "#ffe89e", 1);
          rect(ctx, ox, oy, 1, 1, "#fffdf0");
          rect(ctx, ox + fringe * 3, oy - 3, 1, 1, big ? "#bce9e0" : "#ffd6e0");
        }
      }
    }
    sugarBurst(ctx, clip, frame, view, [cx, cy, radius]) {
      if (frame > 19) return;
      const paint = (x, y) => this.facePoint(view, clip, frame, x, y);
      const shell = paint(cx, cy);
      const r = radius / (view === "close" ? 2.75 : 4);
      // Short tangents read as pieces of one rim before they fly apart.
      if (frame < 7) {
        const chips = [[-.8,-.6],[.3,-.95],[.96,-.28],[.72,.69],[-.2,.98],[-.96,.28]];
        for (const [i, [dx, dy]] of chips.entries()) {
          if (frame > 4 + i % 3) continue;
          const reach = r + frame * (view === "close" ? 1.25 : .85);
          const x = Math.round(shell.sx + dx*reach), y = Math.round(shell.sy + dy*reach + frame*frame*.08);
          const w = Math.abs(dx) < .8 && frame < 4 ? 3 : 1;
          const h = w === 1 && frame < 4 ? 2 : 1;
          rect(ctx,x,y+1,w,h,"#83677f");
          rect(ctx,x,y,w,h,["#ffe6b4","#bce9e0","#ffd1df"][i%3]);
        }
      }
      const [, , noseX, noseY] = clip.anchors[frame];
      // Drop outside her cheek first. The last few steps track her moving nose.
      const t = Math.min(1, Math.max(0, (frame-1)/10)), u = 1-t;
      const endX = noseX + 3, endY = noseY - 3;
      const star = paint(u*u*u*cx + 3*u*u*t*(cx+16) + 3*u*t*t*(cx-12) + t*t*t*endX,
        u*u*u*cy + 3*u*u*t*(cy-17) + 3*u*t*t*(endY+32) + t*t*t*endY);
      const x = Math.round(star.sx), y = Math.round(star.sy);
      const size = frame < 11 && view === "close" ? 3 : frame < 17 ? 2 : 1;
      shine(ctx,x,y,"#896477",size);
      if (size === 3) rect(ctx,x-1,y-1,3,3,"#e7aa70");
      shine(ctx,x,y,"#f5ca78",size-1);
      rect(ctx,x,y,1,1,"#fff5cb");
    }
    expression(ctx, clip, frame, view, id, motion, sparks) {
      const at = (x, y) => {
        const pos = this.facePoint(view, clip, frame, x, y);
        return [Math.round(pos.sx), Math.round(pos.sy)];
      };
      const a = clip.anchors[frame];
      if (id.startsWith("cheek") && frame >= 5 && frame <= 17) {
        const side = id === "cheekLeft" ? -1 : 1;
        const [x, y] = at(
          a[2] + side * (91 + Math.min(frame - 5, 8)),
          a[3] - 20 - (frame - 5) * 2,
        );
        rect(ctx, x, y, 2, 1, "#dea2ba");
        rect(ctx, x + 3, y, 2, 1, "#dea2ba");
        rect(ctx, x, y + 1, 5, 1, "#efbfce");
        rect(ctx, x + 1, y + 2, 3, 1, "#e7acbf");
        rect(ctx, x + 2, y + 3, 1, 1, "#c389a9");
      } else if (id === "sneeze" && frame >= 14 && frame <= 20) {
        // A small breath leaves on the closed-eye beat. Keep its origin on
        // the release drawing so the puff separates as her head rebounds.
        const age = frame - 14;
        const [, , noseX, noseY] = clip.anchors[14];
        const [x, y] = at(noseX, noseY);
        const puffX = x + (view === "close" ? 6 : 4) + 2 * age;
        const puffY = y + (view === "close" ? 5 : 3) + Math.floor(age / 2);
        const shade = "#888093", light = "#fff2de";
        if (age >= 1 && age <= 4) {
          rect(ctx, puffX, puffY - 1, 3, 1, shade);
          rect(ctx, puffX - 1, puffY, 5, 2, shade);
          rect(ctx, puffX, puffY + 2, 3, 1, shade);
          rect(ctx, puffX, puffY, 3, 2, light);
          rect(ctx, puffX + 1, puffY - 1, 1, 1, light);
        } else rect(ctx, puffX, puffY, 2, 1, shade);
        if (age > 1 && age < 6)
          rect(ctx, puffX - 3, puffY - 2, 2, 1, "#ad9ead");
      } else if (id === "brush") {
        for (const spark of sparks) {
          const [x, y] = at(spark.x, spark.y);
          shine(
            ctx,
            x,
            y - 2 - Math.floor(spark.age / 90),
            spark.age < 210 ? "#fff2be" : "#d6a8c3",
            spark.age < 210 ? 1 : 0,
          );
        }
      } else if (id === "reading" || id === "readingMoon") {
        const [x, y] = at(...clip.book[frame]);
        rect(ctx, x + 3, y - 2, 2, 1, "#ffe9a6");
        rect(ctx, x + 4, y - 1, 1, 2, "#ffe9a6");
      } else if (
        clip.target &&
        ["lensFind", "palmTap", "keyChime"].includes(id)
      ) {
        const [x, y] = at(...clip.target[frame]);
        if (id === "keyChime") {
          for (const beat of clip.strikes ?? [5, 14]) {
            const rise = frame - beat;
            if (rise < 0 || rise > 8) continue;
            rect(ctx, x + 5, y - 4 - rise, 1, 3, "#a5e6ce");
            rect(ctx, x + 6, y - 4 - rise, 2, 1, "#a5e6ce");
            rect(ctx, x + 3, y - 2 - rise, 2, 2, "#ffe6aa");
          }
        } else if (id === "lensFind" && frame >= 9 && frame <= 22) {
          // The pupil settles behind the lens on F8. Catch light on the brass
          // rim at 45 degrees, then let the star leave as the hand lowers.
          const [cx, cy] = clip.target[Math.min(frame, 12)];
          const flight = Math.max(0, frame - 12);
          const [sx, sy] = at(cx + 16.5 + 2 * flight, cy - 16.5 - 2.5 * flight);
          const rays = frame < 11 || frame > 18 ? 1 : frame < 13 || frame > 16 ? 2 : 3;
          if (frame < 21) {
            shine(ctx, sx, sy, "#594b60", rays);
            if (rays >= 2) rect(ctx, sx - 1, sy - 1, 3, 3, "#594b60");
            shine(ctx, sx, sy, "#f0c573", rays - 1);
          }
          rect(ctx, sx, sy, 1, 1, "#ffe7aa");
          if (frame >= 13 && frame <= 18)
            rect(ctx, sx - 2, sy + 2, 1, 1, "#e0cfed");
        } else if (id === "palmTap" && frame >= 5 && frame < 12) {
          const step = Math.floor((frame - 5) / 2);
          for (const [dx, dy] of [
            [-1, 0],
            [-1, -1],
            [0, -1],
          ])
            rect(
              ctx,
              x + dx * (4 + step),
              y + dy * (4 + step),
              dx ? 2 : 1,
              dy ? 2 : 1,
              "#ffe9ad",
            );
        }
      }
    }
    emotes(ctx, clip, frame, view, action, events, motion, legacy = false) {
      if (!events?.length || !clip?.anchors?.[frame]) return;
      const a = clip.anchors[frame];
      const at = (x, y) => {
        const pos = this.facePoint(view, clip, frame, x, y);
        return [Math.round(pos.sx), Math.round(pos.sy)];
      };
      for (const e of events) {
        const age = e.age || 0,
          life = e.life || 900;
        if (e.zone === "status" || age >= life || (e.clip && e.clip !== action)) continue;
        const side = e.side || 1;
        let x = a[0] + side * 143, y = a[1] - 52;
        if (e.zone === "cheek") {
          x = a[2] + side * (a[3] - a[1]) * 0.52;
          y = a[3] - side * (a[2] - a[0]) * 0.52;
        } else if (e.zone === "wing") {
          const left = side < 0;
          x = left ? a[4] : a[6];
          y = (left ? a[5] : a[7]) - 22;
        } else if (e.zone === "tail") {
          x = a[8];
          y = a[9] - 24;
        } else if (e.zone === "nose") {
          // Leave the nose and eyes visible while she scrunches her face.
          y = a[3] - 40;
        } else if (e.zone === "hand") {
          const palms = clip.palms?.[frame];
          if (!palms) continue;
          const hand = side < 0 ? 0 : 2;
          x = palms[hand] + side * 15;
          y = palms[hand + 1] - 23;
        } else if (e.zone === "book") {
          const book = clip.book?.[frame];
          if (!book) continue;
          [x, y] = book;
          y -= 12;
        } else if (e.zone === "lens") {
          const target = clip.target?.[frame];
          if (!target) continue;
          [x, y] = target;
          y -= 16;
        }
        let [sx, sy] = at(x, y);
        sx = Math.max(20, Math.min(164, sx));
        sy = Math.max(25, Math.min(148, sy));
        if (motion && e.zone !== "cheek") {
          sy -= Math.min(4, Math.floor(age / 110));
        }
        ctx.save();
        // Crisp stepped pixel pop (no muddy fractional alpha in enhanced mode).
        if (legacy) {
          ctx.globalAlpha = motion
            ? Math.max(0, Math.min(1, Math.min(age / 120, (life - age) / 180)))
            : 1;
        } else if (motion && (age < 45 || life - age < 75)) {
          // Final beat shrinks cleanly into a 1px pixel sparkle instead of fading muddy.
          rect(ctx, sx, sy, 1, 1, "#fff2e8");
          ctx.restore();
          continue;
        }
        this.drawEmote(ctx, e.kind, sx, sy);
        ctx.restore();
      }
    }

    drawEmote(ctx, kind, x, y) {
      if (kind === "heart") {
        const pattern = [".o.o.", "owogo", "ogggg", ".ogo."];
        const colors = { o: "#6f4a62", w: "#fff2e8", g: "#e8849b" };
        pattern.forEach((row, dy) =>
          [...row].forEach((ink, dx) => {
            if (colors[ink])
              rect(ctx, x + dx - 2, y + dy - 2, 1, 1, colors[ink]);
          }),
        );
      } else if (kind === "pout") {
        const col = "#ff96a8";
        rect(ctx, x - 2, y - 1, 2, 1, col);
        rect(ctx, x - 1, y - 2, 1, 2, col);
        rect(ctx, x + 1, y - 1, 2, 1, col);
        rect(ctx, x + 1, y - 2, 1, 2, col);
        rect(ctx, x - 2, y + 1, 2, 1, col);
        rect(ctx, x - 1, y + 1, 1, 2, col);
        rect(ctx, x + 1, y + 1, 2, 1, col);
        rect(ctx, x + 1, y + 1, 1, 2, col);
      } else if (kind === "sparkle") {
        shine(ctx, x, y, "#ffe9a6", 2);
        shine(ctx, x + 5, y - 3, "#d6a8c3", 1);
      } else if (kind === "question") {
        label(ctx, "?", x + 1, y + 1, "#352f41");
        label(ctx, "?", x, y, "#ffe9a6");
      } else if (kind === "exclaim") {
        label(ctx, "!", x + 1, y + 1, "#352f41");
        label(ctx, "!", x, y, "#ffd4d5");
      } else if (kind === "ellipsis") {
        rect(ctx, x + 1, y + 1, 1, 1, "#352f41");
        rect(ctx, x + 4, y + 1, 1, 1, "#352f41");
        rect(ctx, x + 7, y + 1, 1, 1, "#352f41");
        rect(ctx, x, y, 1, 1, "#e1d1f2");
        rect(ctx, x + 3, y, 1, 1, "#e1d1f2");
        rect(ctx, x + 6, y, 1, 1, "#e1d1f2");
      } else if (kind === "sweat") {
        rect(ctx, x, y, 2, 4, "#9bcbbd");
        rect(ctx, x + 1, y - 1, 1, 2, "#c5e7d4");
        rect(ctx, x, y + 3, 2, 1, "#587b90");
      } else if (kind === "note") {
        rect(ctx, x, y, 1, 5, "#cec3e8");
        rect(ctx, x - 2, y + 4, 3, 2, "#cec3e8");
        rect(ctx, x + 3, y + 1, 1, 4, "#a095ac");
        rect(ctx, x + 2, y + 4, 2, 1, "#a095ac");
      } else if (kind === "blush") {
        rect(ctx, x - 2, y, 4, 1, "#f8c0ce");
        rect(ctx, x - 1, y + 1, 3, 1, "#ef9ab0");
      }
    }

    sourcePoint(event, view, clip, frame, unbounded = false) {
      const box = this.canvas.getBoundingClientRect();
      const screenX = ((event.clientX - box.left) / box.width) * faceSide,
        screenY = ((event.clientY - box.top) / box.height) * faceSide;
      const sxShift = clip?.cushion ? 0 : this.shift.dx;
      const syShift = clip?.cushion ? 0 : this.shift.dy;
      const x = screenX - (originX + sxShift),
        y = screenY - (originY(view) + syShift);
      const inside =
        Math.hypot(screenX - faceCenter, screenY - faceCenter) < faceRadius &&
        x >= 0 &&
        x < W &&
        y >= 0 &&
        y < H &&
        screenY >= 23 &&
        screenY < 153;
      if (!inside && !unbounded) return null;
      const [ox, oy] = clip.closeOrigin || [113, 34.5];
      const pan = clip.closePan?.[frame] || 0;
      const point =
        view === "full"
          ? { x: 28 + x * 4, y: 12 + y * 4 }
          : { x: ox + (x + pan) * 2.75, y: oy + y * 2.75 };
      return { ...point, sx: screenX, sy: screenY, inside };
    }
  }
  return Display;
})();
